'use strict';

(function () {
    app.settings = {
        appId: 'ghxgj28e48b8ligc',
        scheme: 'http'
    };
}());
