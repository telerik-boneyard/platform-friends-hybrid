(function () {
    app.constants = {
        defaultPicture: 'http://bs2.cdn.telerik.com/v1/ghxgj28e48b8ligc/8874d2d0-daed-11e5-a158-f5bd909fd4c7'
    };
}());